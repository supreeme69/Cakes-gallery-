(function () {
  if (!window.gsap || !window.THREE || !window.ScrollTrigger) { document.body.classList.add('entered'); const g0 = document.getElementById('gate'); if (g0) g0.remove(); return; }
  gsap.registerPlugin(ScrollTrigger);
  const RM = matchMedia('(prefers-reduced-motion:reduce)').matches;
  const wide = innerWidth > 900;
  const C = h => new THREE.Color(h).convertSRGBToLinear();

  /* ---------- Smooth scroll (Lenis) ---------- */
  let lenis = null;
  if (window.Lenis && !RM) {
    lenis = new Lenis({ lerp: 0.085 });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add(t => lenis.raf(t * 1000));
    gsap.ticker.lagSmoothing(0);
  }
  document.querySelectorAll('a[href^="#"]').forEach(a => a.addEventListener('click', e => {
    const id = a.getAttribute('href'), t = id.length > 1 && document.querySelector(id);
    if (!t) return;
    e.preventDefault();
    lenis ? lenis.scrollTo(t, { offset: -10, duration: 1.6 }) : t.scrollIntoView({ behavior: 'smooth' });
  }));

  /* ---------- Renderer, lights, studio reflections ---------- */
  const host = document.getElementById('webgl-canvas');
  const R = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  R.setPixelRatio(Math.min(devicePixelRatio, 2));
  R.outputEncoding = THREE.sRGBEncoding;
  R.toneMapping = THREE.ACESFilmicToneMapping;
  R.toneMappingExposure = 1.1;
  R.shadowMap.enabled = true;
  R.shadowMap.type = THREE.PCFSoftShadowMap;
  host.appendChild(R.domElement);
  const sc = new THREE.Scene(), cam = new THREE.PerspectiveCamera(34, 1, 0.1, 100);
  cam.position.set(0, 2.4, wide ? 11 : 15);
  cam.lookAt(0, 0, 0);

  const envS = new THREE.Scene();
  envS.add(new THREE.Mesh(new THREE.SphereGeometry(20, 32, 16), new THREE.MeshBasicMaterial({ color: 0x6b5560, side: THREE.BackSide })));
  [[8, 10, 6, 0xfff1dc, 5, 6], [-9, 4, 3, 0xffd9b0, 3, 3], [0, 12, -8, 0xffffff, 4, 4], [0, -8, 0, 0x6b4a3a, 4, 1]].forEach(([x, y, z, c, s, k]) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(s * 2, s * 2), new THREE.MeshBasicMaterial({ color: c, side: THREE.DoubleSide }));
    m.material.color.multiplyScalar(k); m.position.set(x, y, z); m.lookAt(0, 0, 0); envS.add(m);
  });
  sc.environment = new THREE.PMREMGenerator(R).fromScene(envS, 0.04).texture;

  const key = new THREE.DirectionalLight(0xfff1dc, 1.6);
  key.position.set(4, 9, 6); key.castShadow = true; key.shadow.mapSize.set(2048, 2048);
  Object.assign(key.shadow.camera, { left: -6, right: 6, top: 6, bottom: -6, near: 1, far: 30 });
  key.shadow.bias = -0.0005; sc.add(key);
  const rim = new THREE.PointLight(0xffb3cc, 1.2, 30); rim.position.set(-6, 3, -4); sc.add(rim);
  sc.add(new THREE.HemisphereLight(0xffffff, 0x3a2a22, 0.35));

  function resize() { R.setSize(innerWidth, innerHeight); cam.aspect = innerWidth / innerHeight; cam.updateProjectionMatrix(); }
  addEventListener('resize', resize); resize();

  /* ---------- Materials ---------- */
  function noiseTex(n, amp) {
    const c = document.createElement('canvas'); c.width = c.height = n;
    const x = c.getContext('2d'), d = x.createImageData(n, n);
    for (let i = 0; i < d.data.length; i += 4) { d.data[i] = d.data[i + 1] = d.data[i + 2] = 128 + (Math.random() - 0.5) * amp; d.data[i + 3] = 255; }
    x.putImageData(d, 0, 0);
    const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(8, 3); return t;
  }
  const fond = new THREE.MeshPhysicalMaterial({ color: C(0xf1e6d4), roughness: 0.6, bumpMap: noiseTex(256, 46), bumpScale: 0.5, clearcoat: 0.12, clearcoatRoughness: 0.6 });
  const goldM = new THREE.MeshStandardMaterial({ color: C(0xe8a1b0), metalness: 1, roughness: 0.25, side: THREE.DoubleSide });
  const pearlM = new THREE.MeshPhysicalMaterial({ color: C(0xfaf3e8), roughness: 0.25, clearcoat: 1, clearcoatRoughness: 0.1 });
  const ganM = new THREE.MeshPhysicalMaterial({ color: C(0xe0527f), roughness: 0.18, clearcoat: 1, clearcoatRoughness: 0.05 });
  const berryM = new THREE.MeshPhysicalMaterial({ color: C(0xb0122d), roughness: 0.35, clearcoat: 0.7 });
  const blueM = new THREE.MeshPhysicalMaterial({ color: C(0x4b2a5a), roughness: 0.4, clearcoat: 0.6 });
  const mintM = new THREE.MeshStandardMaterial({ color: C(0x4f7a43), roughness: 0.5, side: THREE.DoubleSide });
  const petalM = new THREE.MeshPhysicalMaterial({ color: C(0xf48fb1), roughness: 0.4, clearcoat: 0.3 });
  const standM = new THREE.MeshStandardMaterial({ color: C(0xfbe3ea), metalness: 0.2, roughness: 0.25 });

  /* ---------- Cake building blocks ---------- */
  function tierGeo(r, h, b) {
    const p = [new THREE.Vector2(0, 0), new THREE.Vector2(r - b, 0)];
    for (let i = 1; i <= 6; i++) { const a = i / 6 * Math.PI / 2; p.push(new THREE.Vector2(r - b + Math.sin(a) * b, b - Math.cos(a) * b)); }
    for (let i = 1; i <= 6; i++) { const a = i / 6 * Math.PI / 2; p.push(new THREE.Vector2(r - b + Math.cos(a) * b, h - b + Math.sin(a) * b)); }
    p.push(new THREE.Vector2(0, h));
    return new THREE.LatheGeometry(p, 96);
  }
  const berryG = new THREE.IcosahedronGeometry(0.13, 2);
  (function () { const p = berryG.attributes.position; for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i), z = p.getZ(i), k = 1 + 0.08 * Math.sin(x * 70) * Math.sin(y * 70) * Math.sin(z * 70); p.setXYZ(i, x * k, y * k, z * k); } berryG.computeVertexNormals(); })();
  function flower(sz) {
    const g = new THREE.Group();
    for (let i = 0; i < 7; i++) {
      const p = new THREE.Mesh(new THREE.SphereGeometry(sz, 16, 12), petalM); p.scale.set(1, 0.18, 0.55); p.position.x = sz * 0.9; p.castShadow = true;
      const w = new THREE.Group(); w.add(p); w.rotation.y = i / 7 * 6.283; w.rotation.z = 0.25; g.add(w);
    }
    const c = new THREE.Mesh(new THREE.SphereGeometry(sz * 0.3, 16, 12), goldM); c.position.y = sz * 0.08; g.add(c); return g;
  }
  let flame = null;
  function topDecor(g, r, h) {
    const cd = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.4, 16), new THREE.MeshPhysicalMaterial({ color: C(0xfaf3e8), roughness: 0.3 })); cd.position.y = h + 0.25; cd.castShadow = true; g.add(cd);
    flame = new THREE.Mesh(new THREE.SphereGeometry(0.06, 16, 12), new THREE.MeshBasicMaterial({ color: 0xffc66b, toneMapped: false })); flame.position.y = h + 0.52; flame.add(new THREE.PointLight(0xffb04a, 0.9, 4)); g.add(flame);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.99, r * 0.99, 0.05, 64), ganM); cap.position.y = h + 0.005; cap.castShadow = true; g.add(cap);
    for (let j = 0; j < 14; j++) {
      const a = j / 14 * 6.283 + Math.random() * 0.2, L = 0.12 + Math.random() * 0.4, x = Math.cos(a) * r, z = Math.sin(a) * r;
      const d = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, L, 12), ganM); d.position.set(x, h - L / 2, z);
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 10), ganM); e.position.set(x, h - L, z); g.add(d, e);
    }
    const put = (m, geo, rad, ang, y, sc2) => { const o = new THREE.Mesh(geo, m); o.position.set(Math.cos(ang) * rad, h + y, Math.sin(ang) * rad); o.scale.setScalar(sc2); o.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6); o.castShadow = true; g.add(o); return o; };
    const k = Math.max(r, 0.5);
    for (let j = 0; j < 6; j++) put(berryM, berryG, k * 0.62, j / 6 * 6.283 + 0.3, 0.12, k * 0.8 + 0.4);
    for (let j = 0; j < 4; j++) put(blueM, new THREE.SphereGeometry(0.09, 16, 12), k * 0.4, j / 4 * 6.283 + 0.9, 0.1, 1);
    for (let j = 0; j < 5; j++) { const l = put(mintM, new THREE.SphereGeometry(0.13, 12, 8), k * 0.78, j / 5 * 6.283 + 0.55, 0.05, 1); l.scale.set(1, 0.1, 0.5); l.rotation.set(0, j * 1.3, 0.2); }
    [[0.2, 0.15], [-0.22, -0.1]].forEach(([x, z], i) => { const f = flower(0.2 + k * 0.05); f.position.set(x * k, h + 0.06, z * k); f.rotation.y = i * 2; g.add(f); });
  }

  /* ---------- Cake assembly (rebuilt when tiers change) ---------- */
  const cake = new THREE.Group(); sc.add(cake);
  let tiers = [], bodyMats = [], goldParts = [], mid = 1.3, finish = 0xf1e6d4, goldOn = true;
  function build(n) {
    while (cake.children.length) cake.remove(cake.children[0]);
    tiers = []; bodyMats = []; goldParts = [];
    const H = [0.85, 0.75, 0.65, 0.55]; let y = 0;
    for (let i = 0; i < n; i++) {
      const r = 1.6 * Math.pow(0.72, i), h = H[i], g = new THREE.Group(), m = fond.clone();
      m.color.copy(C([0xf7bfd0, 0xfff3f6, 0xf3a7bf, 0xfff3f6][i % 4])); bodyMats.push(m);
      const body = new THREE.Mesh(tierGeo(r, h, 0.07), m); body.castShadow = body.receiveShadow = true; g.add(body);
      [0.05, h - 0.05].forEach(yy => { const b = new THREE.Mesh(new THREE.TorusGeometry(r + 0.004, 0.016, 12, 96), goldM); b.rotation.x = Math.PI / 2; b.position.y = yy; g.add(b); goldParts.push(b); });
      const cnt = Math.floor(6.283 * r / 0.17), pe = new THREE.InstancedMesh(new THREE.SphereGeometry(0.058, 16, 12), pearlM, cnt), d = new THREE.Object3D();
      for (let j = 0; j < cnt; j++) { const a = j / cnt * 6.283; d.position.set(Math.cos(a) * (r + 0.015), 0.14, Math.sin(a) * (r + 0.015)); d.updateMatrix(); pe.setMatrixAt(j, d.matrix); }
      pe.castShadow = true; g.add(pe);
      for (let j = 0; j < 9; j++) {
        const a = Math.random() * 6.283, f = new THREE.Mesh(new THREE.PlaneGeometry(0.1 + Math.random() * 0.12, 0.07 + Math.random() * 0.09), goldM);
        f.position.set(Math.cos(a) * (r + 0.004), 0.25 + Math.random() * (h - 0.45), Math.sin(a) * (r + 0.004)); f.rotation.set(0, Math.PI / 2 - a, Math.random() * 3); g.add(f); goldParts.push(f);
      }
      g.userData.base = y; g.position.y = y; y += h; cake.add(g); tiers.push(g);
      if (i === n - 1) topDecor(g, r, h);
    }
    mid = y / 2;
    const pl = new THREE.Mesh(new THREE.CylinderGeometry(2.15, 2.1, 0.1, 96), standM); pl.position.y = -0.05; pl.castShadow = pl.receiveShadow = true;
    const st = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.42, 0.5, 48), standM); st.position.y = -0.35;
    const ft = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.3, 0.1, 64), standM); ft.position.y = -0.65; ft.castShadow = true;
    const fl = new THREE.Mesh(new THREE.PlaneGeometry(16, 16), new THREE.ShadowMaterial({ opacity: 0.22 })); fl.rotation.x = -Math.PI / 2; fl.position.y = -0.71; fl.receiveShadow = true;
    cake.add(pl, st, ft, fl);
    goldParts.forEach(p => p.visible = goldOn);
  }
  build(3);

    /* ---------- Butterflies ---------- */
  const wTex = (function () {
    const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
    const g = x.createRadialGradient(40, 128, 10, 150, 110, 160); g.addColorStop(0, '#ffffff'); g.addColorStop(0.45, '#f9c5d5'); g.addColorStop(1, '#ee7fa5');
    x.fillStyle = g; x.strokeStyle = 'rgba(120,30,70,.5)'; x.lineWidth = 4;
    x.beginPath(); x.moveTo(8, 128); x.bezierCurveTo(30, 20, 200, 0, 248, 60); x.bezierCurveTo(260, 110, 160, 135, 8, 128); x.fill(); x.stroke();
    x.beginPath(); x.moveTo(8, 128); x.bezierCurveTo(150, 125, 240, 150, 205, 215); x.bezierCurveTo(160, 260, 40, 220, 8, 128); x.fill(); x.stroke();
    x.fillStyle = 'rgba(255,255,255,.75)'; [[170, 65, 14], [120, 185, 10], [190, 170, 8]].forEach(([a, b, r]) => { x.beginPath(); x.arc(a, b, r, 0, 6.283); x.fill(); });
    const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t;
  })();
  const wGeo = new THREE.PlaneGeometry(1, 1); wGeo.translate(0.5, 0, 0);
  const wMat = new THREE.MeshBasicMaterial({ map: wTex, transparent: true, side: THREE.DoubleSide, depthWrite: false, toneMapped: false });
  const bf = [];
  for (let i = 0; i < (wide ? 10 : 6); i++) {
    const g = new THREE.Group(), wr = new THREE.Mesh(wGeo, wMat), wl = new THREE.Mesh(wGeo, wMat); wl.scale.x = -1; g.add(wr, wl);
    g.scale.setScalar(0.35 + Math.random() * 0.4);
    g.userData = { wr, wl, cx: (Math.random() - 0.5) * 9, cy: (Math.random() - 0.4) * 4, cz: -2 + Math.random() * 3, ax: 1.5 + Math.random() * 2, ay: 0.8 + Math.random(), sp: 0.25 + Math.random() * 0.3, ph: Math.random() * 6.28, fl: 7 + Math.random() * 4 };
    sc.add(g); bf.push(g);
  }

  /* ---------- Scene states ---------- */
  const mob = o => wide ? o : { ...o, x: 0, y: o.y + 1.8, s: o.s * 0.62 };
  const ST = {
    gate: { x: 0, y: -0.1, s: wide ? 1.15 : 0.8, e: 0, d: 0, rot: 0 },
    work: mob({ x: 2.4, y: 0.2, s: 0.85, e: 1, d: 0, rot: 3 }),
    contact: mob({ x: 2.6, y: 0, s: 1.05, e: 0, d: 0, rot: 6.6 })
  };
  const S = { ...ST.gate }, I = { k: RM ? 1 : 0, r: RM ? 0 : -2.5 }, P = { k: 1 };
  const seg = (trig, from, to, a, b) => gsap.fromTo(S, from, { ...to, ease: 'none', immediateRender: false, scrollTrigger: { trigger: trig, start: a, end: b, scrub: 1.2 } });
  // scrolling through the work: the cake pieces fly off in different directions
  seg('#gallery .grid', ST.work, { ...ST.work, d: 1, rot: 4.6, s: 0.95 }, 'top 60%', 'bottom 50%');
  // reaching contact: the pieces come back together
  seg('#contact', { ...ST.work, d: 1, rot: 4.6, s: 0.95 }, ST.contact, 'top 95%', 'top 20%');

  /* ---------- Render loop ---------- */
  let mx = 0, my = 0, tx = 0, ty = 0;
  addEventListener('pointermove', e => { tx = e.clientX / innerWidth - 0.5; ty = e.clientY / innerHeight - 0.5; });
  const clk = new THREE.Clock(), DIR = [[-5.5, -1.2, -2], [5.8, 2.4, -3], [-3.5, 4.5, -4], [4, -3.5, -2]];
  (function loop() {
    const t = clk.getElapsedTime(); mx += (tx - mx) * 0.06; my += (ty - my) * 0.06;
    cake.position.set(S.x, S.y - mid + Math.sin(t * 1.2) * 0.06, 0);
    cake.rotation.set(my * 0.1, S.rot + I.r + t * 0.08 + mx * 0.4, 0);
    cake.scale.setScalar(Math.max(0.001, S.s * I.k * P.k));
    tiers.forEach((g, i) => {
      const q = DIR[i % 4], d = S.d;
      g.position.set(q[0] * d, g.userData.base + S.e * i * 1.4 + q[1] * d, q[2] * d);
      g.rotation.set(d * (i + 1) * 1.2, d * (i % 2 ? 1.6 : -1.6), d * 0.7 * (i + 1));
    });
    if (flame) flame.scale.set(1 + Math.sin(t * 20) * 0.1, 1.8 + Math.sin(t * 13) * 0.25, 1);
    bf.forEach(g => {
      const u = g.userData, a = t * u.sp + u.ph, th = Math.abs(Math.sin(t * u.fl)) * 1.1 + 0.1;
      g.position.set(u.cx + Math.sin(a) * u.ax, u.cy + Math.sin(a * 1.7) * u.ay, u.cz + Math.cos(a) * 1.2);
      g.rotation.set(0.8, 0, Math.sin(a) * 0.5); u.wr.rotation.y = -th; u.wl.rotation.y = th;
    });
    R.render(sc, cam); requestAnimationFrame(loop);
  })();

  /* ---------- Enter screen: click, and the cake opens up ---------- */
  const gate = document.getElementById('gate'); let entered = false;
  if (lenis) lenis.stop();
  const headW = gsap.fromTo('#gallery h2', { clipPath: 'inset(0 0 100% 0)', translate: '0px 40px' }, { clipPath: 'inset(0 0 -20% 0)', translate: '0px 0px', duration: 1.5, ease: 'power4.out', paused: true });
  function enter() {
    if (entered) return; entered = true; gate.style.pointerEvents = 'none';
    const open = () => { document.body.classList.add('entered'); if (lenis) lenis.start(); };
    if (RM) { Object.assign(S, ST.work); open(); gate.remove(); headW.progress(1); ScrollTrigger.refresh(); return; }
    gsap.to('#gate .gt', { opacity: 0, y: -40, filter: 'blur(8px)', duration: 0.8, stagger: 0.1, ease: 'power3.in' });
    gsap.to(gate, { opacity: 0, duration: 1.2, delay: 0.7 });
    gsap.to(S, { x: ST.work.x, y: ST.work.y, s: ST.work.s, rot: ST.work.rot, duration: 2.6, ease: 'power3.inOut' });
    gsap.to(S, { e: 1, duration: 2, delay: 0.6, ease: 'back.out(1.5)' });
    gsap.delayedCall(1.1, () => { open(); ScrollTrigger.refresh(); });
    gsap.delayedCall(1.4, () => headW.play());
    gsap.delayedCall(2.2, () => gate.remove());
  }
  gate.addEventListener('click', enter);
  gate.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); enter(); } });
  if (!RM) gsap.to(I, { k: 1, r: 0, duration: 2.8, ease: 'power3.out', delay: 0.2 });

  /* ---------- Scroll transitions ---------- */
  if (!RM) {
    gsap.utils.toArray('#gallery .grid > div').forEach((t, i) => {
      gsap.fromTo(t, { clipPath: 'inset(14% 10% 14% 10% round 28px)', opacity: 0 }, { clipPath: 'inset(0% 0% 0% 0% round 28px)', opacity: 1, ease: 'none', scrollTrigger: { trigger: t, start: 'top 95%', end: 'top 50%', scrub: true } });
      gsap.fromTo(t, { translate: '0px ' + (i % 2 ? 80 : 30) + 'px' }, { translate: '0px ' + (i % 2 ? -40 : -20) + 'px', ease: 'none', scrollTrigger: { trigger: t, start: 'top bottom', end: 'bottom top', scrub: true } });
    });
    gsap.fromTo('#contact h2', { clipPath: 'inset(0 0 100% 0)', translate: '0px 40px' }, { clipPath: 'inset(0 0 -20% 0)', translate: '0px 0px', duration: 1.4, ease: 'power4.out', scrollTrigger: { trigger: '#contact h2', start: 'top 88%' } });
  }
  if (!RM) gsap.fromTo('#contact .soc', { opacity: 0, translate: '0px 40px' }, { opacity: 1, translate: '0px 0px', stagger: 0.1, duration: 1, ease: 'back.out(1.6)', scrollTrigger: { trigger: '#contact .soc', start: 'top 92%' } });
  addEventListener('load', () => ScrollTrigger.refresh());

/* ---------- My Works: reveal + lightbox ---------- */
  const wk = gsap.utils.toArray('#works .wk');
  if (!RM) {
    gsap.fromTo('#works h2', { clipPath: 'inset(0 0 100% 0)', translate: '0px 40px' }, { clipPath: 'inset(0 0 -20% 0)', translate: '0px 0px', duration: 1.4, ease: 'power4.out', scrollTrigger: { trigger: '#works h2', start: 'top 88%' } });
    wk.forEach(el => gsap.fromTo(el, { clipPath: 'inset(12% 8% 12% 8% round 24px)', opacity: 0, translate: '0px 60px' }, { clipPath: 'inset(0% 0% 0% 0% round 24px)', opacity: 1, translate: '0px 0px', ease: 'none', scrollTrigger: { trigger: el, start: 'top 98%', end: 'top 65%', scrub: true } }));
  }
  const lb = document.getElementById('lb'), lbi = document.getElementById('lb-i'); let cur = 0;
  const show = i => { cur = (i + wk.length) % wk.length; const im = wk[cur].querySelector('img'); lbi.src = im.src; lbi.alt = im.alt; if (!RM) gsap.fromTo(lbi, { scale: 0.92, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.5, ease: 'power3.out' }); };
  const openLb = i => { show(i); lb.classList.remove('hidden'); lb.classList.add('flex'); if (lenis) lenis.stop(); document.body.style.overflow = 'hidden'; };
  const closeLb = () => { lb.classList.add('hidden'); lb.classList.remove('flex'); if (lenis) lenis.start(); document.body.style.overflow = ''; };
  wk.forEach((el, i) => el.addEventListener('click', () => openLb(i)));
  document.getElementById('lb-x').addEventListener('click', closeLb);
  document.getElementById('lb-p').addEventListener('click', () => show(cur - 1));
  document.getElementById('lb-n').addEventListener('click', () => show(cur + 1));
  lb.addEventListener('click', e => { if (e.target === lb) closeLb(); });
  addEventListener('keydown', e => { if (lb.classList.contains('hidden')) return; if (e.key === 'Escape') closeLb(); if (e.key === 'ArrowLeft') show(cur - 1); if (e.key === 'ArrowRight') show(cur + 1); });

  /* ---------- Cursor ---------- */
  if (matchMedia('(pointer:fine)').matches) {
    const d = document.getElementById('cursor-dot'), a = document.getElementById('cursor-aura');
    a.style.transition = 'width .3s,height .3s,border-color .3s,background .3s';
    gsap.set([d, a], { xPercent: -50, yPercent: -50 });
    const dx = gsap.quickTo(d, 'x', { duration: 0.1 }), dy = gsap.quickTo(d, 'y', { duration: 0.1 }), ax = gsap.quickTo(a, 'x', { duration: 0.45, ease: 'power3' }), ay = gsap.quickTo(a, 'y', { duration: 0.45, ease: 'power3' });
    addEventListener('pointermove', e => { dx(e.clientX); dy(e.clientY); ax(e.clientX); ay(e.clientY); });
    document.querySelectorAll('a,button,.liquid-glass,#gate').forEach(el => {
      el.addEventListener('pointerenter', () => document.body.classList.add('cursor-hover'));
      el.addEventListener('pointerleave', () => document.body.classList.remove('cursor-hover'));
    });
  }

  })();
